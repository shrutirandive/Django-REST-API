from django.db import models
from django.shortcuts import render, redirect

# Create your models here.
class Country(models.Model):
    name=models.CharField(max_length=50,null=True)
    code=models.CharField(max_length=10,null=True)
    capital=models.CharField(max_length=50,null=True)
    population=models.IntegerField(default=0,null=True)

    def __str__(self):
        return self.name
    
    def saveEmp(self):
        self.save()
