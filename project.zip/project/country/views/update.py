from django.shortcuts import render, redirect
from django.views import View
from country.models.country import Country

from country.serializers import CountrySerializer
from rest_framework import status
from rest_framework.decorators import api_view
#from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response

@api_view(["PUT"])
@csrf_exempt
def update_country(request, id):
    country=Country.objects.get(id=id)
    serializer=CountrySerializer(instance=country, data=request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)