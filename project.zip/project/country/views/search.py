from django.shortcuts import render, redirect
from django.views import View
from django.db.models import Q
from country.models.country import Country

from country.serializers import CountrySerializer
from rest_framework import status
from rest_framework.decorators import api_view
from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework.filters import SearchFilter
from rest_framework.generics import ListAPIView

class CountryList(ListAPIView):
    queryset=Country.objects.all()
    serializer_class=CountrySerializer
    filter_backends=[SearchFilter]
    search_fields=['name','capital']


'''
#VIEWS
def search(request):
    if request.method =='GET':
        query=request.GET.get('q')

        submitbutton=request.GET.get('submit')

        if query is not None:
            search=Q(name__icontains=query)
            results=Country.objects.filter(search).distinct()
            context={'results':results, 'submitbutton':submitbutton}

            return render(request, 'search.html', context)
        else:
            return render(request, 'search.html')
    else:
        return render(request, 'search.html')
'''