from django.shortcuts import render, redirect
from django.views import View
from country.models.country import Country

from country.serializers import CountrySerializer
from rest_framework import status
from rest_framework.decorators import api_view
#from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response

@api_view(["GET"])
@csrf_exempt
def display_country(request):
    user = request.user.id
    country = Country.objects.all()
    serializer = CountrySerializer(country, many=True)
    return Response(serializer.data)


'''
#VIEWS
def display(request):
    country=Country.objects.all()
    return render(request, 'display.html', {'country':country})
    '''