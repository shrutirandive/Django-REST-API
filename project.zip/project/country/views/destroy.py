from django.shortcuts import render, redirect
from django.views import View
from country.models.country import Country

from country.serializers import CountrySerializer
from rest_framework import status
from rest_framework.decorators import api_view
#from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response

@api_view(["DELETE"])
def delete_country(request,id):
    country=Country.objects.get(id=id)
    country.delete()
    return Response('Deleted successfully')

'''
#VIEWS

def destroy(request, id):
    c=Country.objects.get(id=id)
    c.delete()
    return redirect('/display')
'''