from django.shortcuts import render, redirect
from django.views import View
from country.models.country import Country

from country.serializers import CountrySerializer
from rest_framework.decorators import api_view
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status
from rest_framework.response import Response

@api_view(['POST'])
@csrf_exempt
def add_country(request):
    serializer=CountrySerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

