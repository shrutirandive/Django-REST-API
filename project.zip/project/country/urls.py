from django.contrib import admin
from django.urls import path, include

from .views.create import add_country
from .views.display import display_country
from .views.destroy import delete_country
from .views.update import update_country
from .views.search import CountryList

urlpatterns=[
    path('add',add_country),
    path('',display_country),
    path('delete/<int:id>',delete_country),
    path('update/<int:id>',update_country),
    path('search/',CountryList.as_view()),
]

